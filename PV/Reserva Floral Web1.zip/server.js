require('dotenv').config();
const express = require('express');
const { Pool } = require('pg');

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static('public'));
app.use(express.json());

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Inicializar tablas y actualizar esquema dinámicamente
const inicializarDB = async () => {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS arreglos_florales (
      id SERIAL PRIMARY KEY,
      nombre VARCHAR(255),
      descripcion TEXT,
      precio DECIMAL(10,2),
      imagen_url TEXT,
      categoria VARCHAR(100)
    );
    CREATE TABLE IF NOT EXISTS ordenes (
      id SERIAL PRIMARY KEY,
      cliente_nombre VARCHAR(150),
      cliente_telefono VARCHAR(20),
      direccion_entrega TEXT,
      fecha_entrega DATE,
      total DECIMAL(10,2),
      estado VARCHAR(50) DEFAULT 'Pendiente',
      creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
  `);
  
  // Actualizar tabla maestra para nuevas variantes (ignora si ya existen)
  const alterQueries = [
    "ALTER TABLE arreglos_florales ADD COLUMN imagenes TEXT;",
    "ALTER TABLE arreglos_florales ADD COLUMN opcion_foto BOOLEAN DEFAULT false;",
    "ALTER TABLE arreglos_florales ADD COLUMN tamanos TEXT;",
    "ALTER TABLE arreglos_florales ADD COLUMN cobertura TEXT;"
  ];
  for (let q of alterQueries) {
    try { await pool.query(q); } catch (e) {} 
  }
};
inicializarDB();

// API: Obtener Catálogo
app.get('/api/catalogo', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM arreglos_florales ORDER BY id DESC');
    res.json(result.rows);
  } catch (error) { res.status(500).json({ error: 'Error del servidor' }); }
});

// API: Crear Producto
app.post('/api/catalogo', async (req, res) => {
  const { nombre, descripcion, precio, imagen_url, categoria, imagenes, opcion_foto, tamanos, cobertura } = req.body;
  try {
    const query = `INSERT INTO arreglos_florales (nombre, descripcion, precio, imagen_url, categoria, imagenes, opcion_foto, tamanos, cobertura) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`;
    const result = await pool.query(query, [nombre, descripcion, precio, imagen_url, categoria, imagenes, opcion_foto, tamanos, cobertura]);
    res.json(result.rows[0]);
  } catch (error) { res.status(500).json({ error: 'Error al insertar' }); }
});

// API: Editar Producto
app.put('/api/catalogo/:id', async (req, res) => {
  const { nombre, descripcion, precio, imagen_url, categoria, imagenes, opcion_foto, tamanos, cobertura } = req.body;
  try {
    const query = `UPDATE arreglos_florales SET nombre=$1, descripcion=$2, precio=$3, imagen_url=$4, categoria=$5, imagenes=$6, opcion_foto=$7, tamanos=$8, cobertura=$9 WHERE id=$10 RETURNING *`;
    const result = await pool.query(query, [nombre, descripcion, precio, imagen_url, categoria, imagenes, opcion_foto, tamanos, cobertura, req.params.id]);
    res.json(result.rows[0]);
  } catch (error) { res.status(500).json({ error: 'Error al actualizar' }); }
});

// API: Eliminar Producto
app.delete('/api/catalogo/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM arreglos_florales WHERE id = $1', [req.params.id]);
    res.json({ exito: true });
  } catch (error) { res.status(500).json({ error: 'Error al eliminar' }); }
});

// API: Procesar Checkout
app.post('/api/ordenes', async (req, res) => {
  const { cliente, telefono, direccion, fecha, total, carrito } = req.body;
  try {
    const query = `INSERT INTO ordenes (cliente_nombre, cliente_telefono, direccion_entrega, fecha_entrega, total) VALUES ($1, $2, $3, $4, $5) RETURNING *`;
    const result = await pool.query(query, [cliente, telefono, direccion, fecha, total]);
    res.json({ exito: true, orden: result.rows[0] });
  } catch (error) { res.status(500).json({ error: 'Falla al procesar pago' }); }
});

app.listen(port, () => console.log(`Servidor transaccional en puerto ${port}`));